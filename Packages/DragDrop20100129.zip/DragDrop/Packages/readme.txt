This folder contains the design-time package source files.

To install a package, open it in Delphi, select build and then install.