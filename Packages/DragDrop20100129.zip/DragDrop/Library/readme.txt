This is the output folder.

The sub folders contains the binary output (.dcu, .obj, .bpl, etc) for each supported compiler.