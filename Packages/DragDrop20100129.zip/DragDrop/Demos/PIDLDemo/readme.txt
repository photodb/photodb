PIDLDemo

This application demonstrates how to drag and drop PIDLs (shell object
descriptors).

