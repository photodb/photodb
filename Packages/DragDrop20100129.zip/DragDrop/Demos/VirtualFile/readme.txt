VirtualFile

This application demonstrates how to transfer file content or virtual files
(files which doesn't exist physically on disk).

The application uses the TDropEmptySource and TDropEmptyTarget components and
extends, at run time, them with a custom data format (TVirtualFileDataFormat).

