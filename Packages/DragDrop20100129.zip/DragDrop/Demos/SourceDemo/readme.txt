SimpleSourceDemo

This application demonstrates how to drag file names from your application to
other applications (e.g. the Explorer) using the TDropFileSource component.

Only copy and link operations are enabled in this demo to avoid "accidents". The
TDropFileSource.DragTypes property control which drag/drop operations the drop
source allows.

