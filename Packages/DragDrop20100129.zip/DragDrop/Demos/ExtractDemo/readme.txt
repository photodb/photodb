ExtractDemo

This application is undocumented.

