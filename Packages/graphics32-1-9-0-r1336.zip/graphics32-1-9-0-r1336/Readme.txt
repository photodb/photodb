See Graphics32.chm file for installation instructions, list of changes, license, and reference.

SUPPORT
-------

For latest news and support visit the Graphics32 home page at http://g32.org and the newsgroup at g32org.public.graphics32.
For the lastest version please visit http://sourceforge.net/projects/graphics32


DONATIONS
---------

Given that Graphics32 is licensed under the terms of the MPL 1.1 and alternatively the LGPL 2.1 with linking exception, you can use the Graphics32 package free of charge even for commercial and shareware applications. However, if you wish to express your appreciation for the time Alex Denisov spend on developing, documenting and supporting the initial version, he does accept and appreciate donations.

If you wish to make your donation, visit the site above. The base amount is US$20, but if you would like to donate more, feel free to order multiple copies of the "Graphics32/G32 donation" product.

Thank you for your support.
