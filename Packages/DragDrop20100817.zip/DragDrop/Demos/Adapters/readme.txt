Adapter

This application demonstrates how to extend the existing target or source
components with support for additional data formats using the TDataFormatAdapter
component.

The TDataFormatAdapter component is an easy alternative to having to write a
custom component in order to combine different data formats into one target
component.

