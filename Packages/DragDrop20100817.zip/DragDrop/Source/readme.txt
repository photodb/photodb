This folder contains the library source files.
