This awk script is used to generate a VB6 module with all the VB6 declaration needed to call FreeImage functions. 

How to use this script
----------------------
Under Linux / Unix, just execute the following commands : 

chmod 755 genbas.sh
./genbas.sh


This will generate a file named modFreeImage.bas that you can include in your VB6 project in order to have access to all FreeImage functions.

Ryan Rubley
<ark42 at users.sourceforge.net>
